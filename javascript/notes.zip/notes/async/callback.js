'use strict';

// JavaScript is synchronous.(자바스크립트는 동기적이다)
// Execute the code block by orger after hoisting. (호이스팅이 된 이후부터 우리가 작성한 코드대로 하나하나씩 동기적으로 실행된다는 말)
// hoisting: var, function declaration
console.log('1');
//비동기적 예시 -> 우리가 지정한 시간이 되면 함수를 호출함
setTimeout(() => console.log('2'), 1000);
//1초가 지나면 consolelog2를 출력하라는 말임
console.log('3');
//1, 3, 2 순서로 출력됨. 

// Synchronous callback  (즉각적실행)
function printImmediately(print) {
  print();
}
printImmediately(() => console.log('hello'));

// Asynchronous callback (언제실행될지 예측할수없는)
function printWithDelay(print, timeout) {
  setTimeout(print, timeout);        //인자 또쓰는게 이해안감. 감싸주고 그대로 실행하는 함수라고 설명은 해주는데. 
}
printWithDelay(() => console.log('async callback'), 2000);

// Callback Hell example
class UserStorage {
  loginUser(id, password, onSuccess, onError) {
    setTimeout(() => {
      if (
        (id === 'ellie' && password === 'dream') ||
        (id === 'coder' && password === 'academy')
      ) {
        onSuccess(id);
      } else {
        onError(new Error('not found'));
      }
    }, 2000);   //시간을 delay줘서 서버랑 통신하는 것처럼
  }

  //사용자의 역할을 따로 받아와야 된다는 api라고 가정한것 
  getRoles(user, onSuccess, onError) {
    setTimeout(() => {
      if (user === 'ellie') {
        onSuccess({ name: 'ellie', role: 'admin' });
      } else {
        onError(new Error('no access'));
      }
    }, 1000);   
  }
}

const userStorage = new UserStorage();
const id = prompt('enter your id');
const password = prompt('enter your passrod');
userStorage.loginUser(    
  id,
  password,
  user => {
    userStorage.getRoles(
      user,
      userWithRole => {
        alert(
          `Hello ${userWithRole.name}, you have a ${userWithRole.role} role`
        );
      },
      error => {
        console.log(error);
      }
    );
  },
  error => {
    console.log(error);
  }
);
